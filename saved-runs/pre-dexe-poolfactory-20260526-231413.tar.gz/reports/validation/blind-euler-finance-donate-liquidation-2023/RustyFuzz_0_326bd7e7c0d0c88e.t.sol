// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";

contract RustyFuzzPoC is Test {
    address constant FUZZER_ADDRESS = 0x583c21631c48D442B5C0E605d624f54A0B366c72;
    uint256 constant FORK_BLOCK = 16817995;
    string constant RPC_URL_ENV = "ETH_RPC_URL";

    function setUp() public virtual {
        vm.createSelectFork(vm.envString(RPC_URL_ENV), FORK_BLOCK);
        vm.label(FUZZER_ADDRESS, "RustyFuzz primary caller");
    }

    function testReplay_RustyFuzz_326bd7e7() public {
        // Finding class: InvariantViolation("lending health invariant")


        // Transaction 1
        vm.deal(0x583c21631c48D442B5C0E605d624f54A0B366c72, 100 ether);
        vm.label(0x583c21631c48D442B5C0E605d624f54A0B366c72, "RustyFuzz caller 1");
        vm.label(0x27182842E098f60e3D576794A5bFFb0777E025d3, "RustyFuzz target 1");
        vm.prank(0x583c21631c48D442B5C0E605d624f54A0B366c72);
        (bool ok0, bytes memory ret0) = address(0x27182842E098f60e3D576794A5bFFb0777E025d3).call{value: 0}(hex"");
        emit log_named_uint("tx 1 gasleft", gasleft());
        if (!ok0) {
            emit log_bytes(ret0);
        }

        assertRustyFuzzProtocolEvidence();

        emit log_string("RustyFuzz finding: pack=Lending severity=High vuln=InvariantViolation(\"lending health invariant\")");
        emit log_string("RustyFuzz evidence: blind rediscovery synthesized lending donation/liquidation candidate using driver `lending-donation-liquidation` without exploit calldata; replay backend `cached-fork-fixture` executed 1 txs with 5 storage diffs; equivalence_class=Euler donate-to-reserves liquidation; expected_invariant=lending health invariant; synthesized_sequence=#0 caller=0x583c21631c48D442B5C0E605d624f54A0B366c72 target=0x27182842E098f60e3D576794A5bFFb0777E025d3 value=0 input=0x");
        assertTrue(ok0, "oracle transaction did not replay successfully");
        assertGt(0x27182842E098f60e3D576794A5bFFb0777E025d3.code.length, 0, "protocol target has no code");
        assertEq(uint256(vm.load(0x27182842E098f60e3D576794A5bFFb0777E025d3, bytes32(0x0000000000000000000000000000000000000000000000000000000000000000))), uint256(0x0000000000000000000000000000000000000000000000000000000000000001), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x27182842E098f60e3D576794A5bFFb0777E025d3, bytes32(0x0000000000000000000000000000000000000000000000000000000000000001))), uint256(0x0000000000000000000000000000000000000000000000000000000000000001), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x27182842E098f60e3D576794A5bFFb0777E025d3, bytes32(0x0000000000000000000000000000000000000000000000000000000000000002))), uint256(0x00000000000000000000000000000000000000000000000000000000000003e8), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x27182842E098f60e3D576794A5bFFb0777E025d3, bytes32(0x0000000000000000000000000000000000000000000000000000000000000003))), uint256(0x0000000000000000000000000000000000000000000000000de0b6b3a7640000), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x27182842E098f60e3D576794A5bFFb0777E025d3, bytes32(0x0000000000000000000000000000000000000000000000000000000000000004))), uint256(0x0000000000000000000000000000000000000000000000000000000000000100), "storage diff not reproduced");

        assertRustyFuzzInvariant();
    }

    function assertRustyFuzzInvariant() internal virtual {
        // Optional extension point for target-specific invariants. Protocol
        // oracle evidence above is asserted directly when available.
    }


    function rustyFuzzWord(bytes memory ret, uint256 offset) internal pure returns (uint256 word) {
        require(ret.length >= offset + 32, "RustyFuzz return word out of bounds");
        assembly {
            word := mload(add(add(ret, 32), offset))
        }
    }

    function assertRustyFuzzVaultAccountingEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "vault/accounting evidence transaction changed status");
        if (ret.length >= 32) {
            uint256 observed = rustyFuzzWord(ret, 0);
            assertLt(observed, type(uint256).max, "vault/accounting return saturated unexpectedly");
        }
    }

    function assertRustyFuzzMarketEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "market/oracle evidence transaction changed status");
        if (ret.length >= 64) {
            uint256 first = rustyFuzzWord(ret, 0);
            uint256 second = rustyFuzzWord(ret, 32);
            assertTrue(first != 0 || second != 0, "market evidence returned empty reserve-like words");
        }
    }

    function assertRustyFuzzGovernanceEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "governance evidence transaction changed status");
        assertLe(ret.length, 4096, "governance evidence returned unexpectedly large payload");
    }

}
