# RustyFuzz Campaign Artifact

- input_id: `ce4baf60ebae286b`
- reason: `protocol-oracle-finding`
- confidence: `71`
- score: `1610`
- target: `Some(0xa03d480cd2e10ad36ed098898357dbe4c349fb02)`
- dedup_key: `c24270fe57477710fc328608b056341063933a176291eee48f8dd823e7405b19`
- findings: `Erc20:AccountingDesync, Erc20:AccountingDesync`

## False-positive risks
- AccountingDesync evidence is heuristic unless replay/minimization preserves it
- fork-specific balances, roles, or oracle state may affect reproducibility
- AccountingDesync evidence is heuristic unless replay/minimization preserves it
- fork-specific balances, roles, or oracle state may affect reproducibility

## Next command
`cargo run --release -- fuzz --chain evm --contract 0xA03d480cd2E10Ad36ED098898357DBe4C349fB02`
