# RustyFuzz Campaign Artifact

- input_id: `b743cafb41cd71ca`
- reason: `high-score-non-success-status`
- confidence: `5`
- score: `554`
- target: `Some(0xa03d480cd2e10ad36ed098898357dbe4c349fb02)`
- dedup_key: `388d5f4b9670fb2335e3b1f60a3e2dcf2406abcd14a1c55198634df2dab33640`
- findings: ``

## False-positive risks
- score-only artifact; replay before treating as vulnerability evidence
- state novelty or economic pressure may be benign protocol behavior

## Next command
`cargo run --release -- fuzz --chain evm --contract 0xA03d480cd2E10Ad36ED098898357DBe4C349fB02`
