# RustyFuzz Campaign Artifact

- input_id: `fbc0ef3ec998e3ea`
- reason: `protocol-oracle-finding`
- confidence: `71`
- score: `1610`
- target: `Some(0xa03d480cd2e10ad36ed098898357dbe4c349fb02)`
- dedup_key: `95663649c4b03e1ea5bd849c7e23d553c8a814d9733ec1daa613bce44e4cc9f1`
- findings: `Erc20:AccountingDesync, Erc20:AccountingDesync`

## False-positive risks
- AccountingDesync evidence is heuristic unless replay/minimization preserves it
- fork-specific balances, roles, or oracle state may affect reproducibility
- AccountingDesync evidence is heuristic unless replay/minimization preserves it
- fork-specific balances, roles, or oracle state may affect reproducibility

## Next command
`cargo run --release -- fuzz --chain evm --contract 0xA03d480cd2E10Ad36ED098898357DBe4C349fB02`
