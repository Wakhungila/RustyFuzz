// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";

contract RustyFuzzPoC is Test {
    address constant FUZZER_ADDRESS = 0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa;
    uint256 constant FORK_BLOCK = 22000000;
    string constant RPC_URL = "https://eth-mainnet.g.alchemy.com/v2/ss6Dr9W68q0BWejzkjELM";

    function setUp() public virtual {
        vm.createSelectFork(RPC_URL, FORK_BLOCK);
        vm.label(FUZZER_ADDRESS, "RustyFuzz primary caller");
    }

    function testReplay_RustyFuzz_e5af0279() public {
        // Finding class: VaultInflation


        // Transaction 1
        vm.deal(0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa, 100 ether);
        vm.label(0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa, "RustyFuzz caller 1");
        vm.label(0x1000000000000000000000000000000000000462, "RustyFuzz target 1");
        vm.prank(0xaAaAaAaaAaAaAaaAaAAAAAAAAaaaAaAaAaaAaaAa);
        (bool ok0, bytes memory ret0) = address(0x1000000000000000000000000000000000000462).call{value: 0}(hex"b6b55f250000000000000000000000000000000000000000000000000de0b6b3a7640000");
        emit log_named_uint("tx 1 gasleft", gasleft());
        if (!ok0) {
            emit log_bytes(ret0);
        }

        assertRustyFuzzProtocolEvidence();

        emit log_string("RustyFuzz finding: pack=Erc4626 severity=High vuln=VaultInflation");
        emit log_string("RustyFuzz evidence: deposit-like call caused 1 large vault storage deltas without nonzero share/accounting reads");
        assertTrue(ok0, "oracle transaction did not replay successfully");
        assertGt(0x1000000000000000000000000000000000000462.code.length, 0, "protocol target has no code");
        assertRustyFuzzVaultAccountingEvidence(ok0, ret0);
        assertEq(uint256(vm.load(0x1000000000000000000000000000000000000462, bytes32(0x0000000000000000000000000000000000000000000000000000000000000000))), uint256(0x0000000000000000000000000000000000000000000000000000000000000001), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x1000000000000000000000000000000000000462, bytes32(0x0000000000000000000000000000000000000000000000000000000000000001))), uint256(0x0000000000000000000000000000000000000000000000000000000000000001), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x1000000000000000000000000000000000000462, bytes32(0x0000000000000000000000000000000000000000000000000000000000000002))), uint256(0x00000000000000000000000000000000000000000000000000000000000003e8), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x1000000000000000000000000000000000000462, bytes32(0x0000000000000000000000000000000000000000000000000000000000000003))), uint256(0x0000000000000000000000000000000000000000000000000de0b6b3a7640000), "storage diff not reproduced");
        assertEq(uint256(vm.load(0x1000000000000000000000000000000000000462, bytes32(0x0000000000000000000000000000000000000000000000000000000000000004))), uint256(0x0000000000000000000000000000000000000000000000000000000000000100), "storage diff not reproduced");

        assertRustyFuzzInvariant();
    }

    function assertRustyFuzzInvariant() internal virtual {
        // Optional extension point for target-specific invariants. Protocol
        // oracle evidence above is asserted directly when available.
    }


    function rustyFuzzWord(bytes memory ret, uint256 offset) internal pure returns (uint256 word) {
        require(ret.length >= offset + 32, "RustyFuzz return word out of bounds");
        assembly {
            word := mload(add(add(ret, 32), offset))
        }
    }

    function assertRustyFuzzVaultAccountingEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "vault/accounting evidence transaction changed status");
        if (ret.length >= 32) {
            uint256 observed = rustyFuzzWord(ret, 0);
            assertLt(observed, type(uint256).max, "vault/accounting return saturated unexpectedly");
        }
    }

    function assertRustyFuzzMarketEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "market/oracle evidence transaction changed status");
        if (ret.length >= 64) {
            uint256 first = rustyFuzzWord(ret, 0);
            uint256 second = rustyFuzzWord(ret, 32);
            assertTrue(first != 0 || second != 0, "market evidence returned empty reserve-like words");
        }
    }

    function assertRustyFuzzGovernanceEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "governance evidence transaction changed status");
        assertLe(ret.length, 4096, "governance evidence returned unexpectedly large payload");
    }

}
