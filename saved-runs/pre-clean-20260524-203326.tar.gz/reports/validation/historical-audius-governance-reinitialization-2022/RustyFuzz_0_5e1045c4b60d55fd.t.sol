// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";

contract RustyFuzzPoC is Test {
    address constant FUZZER_ADDRESS = 0xa0c7BD318D69424603CBf91e9969870F21B8ab4c;
    uint256 constant FORK_BLOCK = 15201793;
    string constant RPC_URL_ENV = "ETH_RPC_URL";

    function setUp() public virtual {
        vm.createSelectFork(vm.envString(RPC_URL_ENV), FORK_BLOCK);
        vm.label(FUZZER_ADDRESS, "RustyFuzz primary caller");
    }

    function testReplay_RustyFuzz_5e1045c4() public {
        // Finding class: PrivilegeEscalation


        // Transaction 1
        vm.deal(0xa0c7BD318D69424603CBf91e9969870F21B8ab4c, 100 ether);
        vm.label(0xa0c7BD318D69424603CBf91e9969870F21B8ab4c, "RustyFuzz caller 1");
        vm.label(0xbdbB5945f252bc3466A319CDcC3EE8056bf2e569, "RustyFuzz target 1");
        vm.prank(0xa0c7BD318D69424603CBf91e9969870F21B8ab4c);
        (bool ok0, bytes memory ret0) = address(0xbdbB5945f252bc3466A319CDcC3EE8056bf2e569).call{value: 0}(hex"5bc7c6ac00000000000000000000000000000000000000000000000000000000000000540000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004");
        emit log_named_uint("tx 1 gasleft", gasleft());
        if (!ok0) {
            emit log_bytes(ret0);
        }

        assertRustyFuzzProtocolEvidence();

        emit log_string("RustyFuzz finding: pack=Governance severity=High vuln=PrivilegeEscalation");
        emit log_string("RustyFuzz evidence: provider-side eth_call replay succeeded for 1 txs at historical fork block 15201793; expected_invariant=access control; local storage diffs unavailable in provider fallback; this is real fork-state replay, not a synthetic cached runtime");
        assertTrue(ok0, "oracle transaction did not replay successfully");
        assertGt(0xbdbB5945f252bc3466A319CDcC3EE8056bf2e569.code.length, 0, "protocol target has no code");
        assertRustyFuzzGovernanceEvidence(ok0, ret0);

        assertRustyFuzzInvariant();
    }

    function assertRustyFuzzInvariant() internal virtual {
        // Optional extension point for target-specific invariants. Protocol
        // oracle evidence above is asserted directly when available.
    }


    function rustyFuzzWord(bytes memory ret, uint256 offset) internal pure returns (uint256 word) {
        require(ret.length >= offset + 32, "RustyFuzz return word out of bounds");
        assembly {
            word := mload(add(add(ret, 32), offset))
        }
    }

    function assertRustyFuzzVaultAccountingEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "vault/accounting evidence transaction changed status");
        if (ret.length >= 32) {
            uint256 observed = rustyFuzzWord(ret, 0);
            assertLt(observed, type(uint256).max, "vault/accounting return saturated unexpectedly");
        }
    }

    function assertRustyFuzzMarketEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "market/oracle evidence transaction changed status");
        if (ret.length >= 64) {
            uint256 first = rustyFuzzWord(ret, 0);
            uint256 second = rustyFuzzWord(ret, 32);
            assertTrue(first != 0 || second != 0, "market evidence returned empty reserve-like words");
        }
    }

    function assertRustyFuzzGovernanceEvidence(bool ok, bytes memory ret) internal {
        assertTrue(ok, "governance evidence transaction changed status");
        assertLe(ret.length, 4096, "governance evidence returned unexpectedly large payload");
    }

}
